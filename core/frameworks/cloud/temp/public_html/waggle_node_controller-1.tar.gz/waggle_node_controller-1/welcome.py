from uuid import getnode as get_mac
from commands import getoutput as bash

print "Congratulations! We have successfully installed WAggLE V1. The sensor updates from this installation of WAggLE are available at the following link-"
print "\twww.mcs.anl.gov/~brhodes/data/"+ str(get_mac()) +".txt"
print "As part of this installation the Temperature and other sensors attached to this system were sent to the WAggLE cloud storage. To send new updates to the cloud, please execute the script WAggLESensors.sh in the current directory."

bash("echo 'The sensor updates from this installation of WAggLE are available at the following link' > WAggLE_data_location.txt")
bash("echo 'www.mcs.anl.gov/~brhodes/data/"+ str(get_mac()) + ".txt' >> WAggLE_data_location.txt")
#bash("chmod u+x file.sh")
