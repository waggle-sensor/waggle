#!/bin/bash
python ./waggle_files/waggle_node_controller-1/sensor_data.py
