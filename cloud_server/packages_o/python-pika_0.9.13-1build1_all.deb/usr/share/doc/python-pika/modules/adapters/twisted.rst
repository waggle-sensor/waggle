Twisted Connection Adapter
==========================
.. automodule:: pika.adapters.twisted_connection

.. autoclass:: pika.adapters.twisted_connection.TwistedConnection
  :members:
  :inherited-members:

.. autoclass:: pika.adapters.twisted_connection.TwistedProtocolConnection
  :members:
  :inherited-members:

.. autoclass:: pika.adapters.twisted_connection.TwistedChannel
  :members:
  :inherited-members:
